#!/bin/sh


#The MIT License (MIT)
#
#Copyright (c) 2016 Sudar Abisheck
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.


_DOMAIN="127.0.0.1"
_PORT="__PORT__"
_IGNORE_PROXY="'localhost'"
_ENV_FILE_PATH="/etc/environment"
_APT_FILE_PATH="/etc/apt/apt.conf"

_MODE_MANUAL="manual"
_MODE_NONE="none"
_MODE_AUTO="auto"
#_CONFIGURATION_URL=""

######  GNOME3 proxy settings
set_gnome_global () {
	set_gnome_direct
	gsettings set org.gnome.system.proxy mode $_MODE_MANUAL
	gsettings set org.gnome.system.proxy.socks host $_DOMAIN
	gsettings set org.gnome.system.proxy.socks port $_PORT
	gsettings set org.gnome.system.proxy ignore-hosts "['localhost', '127.0.0.0/8', '10.0.0.0/8', '192.168.0.0/16', '172.16.0.0/12',  $_IGNORE_PROXY ]"
}
set_gnome_local () {
	set_gnome_direct
	gsettings set org.gnome.system.proxy mode $_MODE_AUTO
	gsettings set org.gnome.system.proxy autoconfig-url "__PROXY_URL__"
}

set_gnome_direct () {
	gsettings set org.gnome.system.proxy mode $_MODE_NONE
	gsettings set org.gnome.system.proxy autoconfig-url ''
	gsettings set org.gnome.system.proxy.socks host ''
	gsettings set org.gnome.system.proxy.socks port 0
	gsettings set org.gnome.system.proxy.http host ''
	gsettings set org.gnome.system.proxy.http port 0
	gsettings set org.gnome.system.proxy.https host ''
	gsettings set org.gnome.system.proxy.https port 0
	gsettings set org.gnome.system.proxy.ftp host ''
	gsettings set org.gnome.system.proxy.ftp port 0
}


###### All proxies ######
set_proxy_global () {
	set_gnome_global
	echo "\t** System proxy set_gnome_global  -  OK"
}
set_proxy_local () {
	set_gnome_local
	echo "\t** System proxy set_gnome_local  -  OK"
}
set_proxy_direct () {
	set_gnome_direct
	echo "\t** System proxy set_gnome_direct  -  OK"
}


case $1 in  

	'off')
		set_gnome_direct
	;;

	'global')
		set_gnome_global
	;;

	'local')
		set_gnome_local
	;;

	*)
 		exit 1
	;;
esac

exit 0

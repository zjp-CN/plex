sudo chmod u+x sspd
sudo chmod u+x Plex
sudo chmod u+x Plex.sh
sudo chmod u+x ./linuxtrd/*
